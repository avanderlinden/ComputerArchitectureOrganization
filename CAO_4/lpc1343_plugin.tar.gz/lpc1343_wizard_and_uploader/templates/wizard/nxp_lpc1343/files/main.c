#include "LPC13xx.h"

int main (void)
{
	while (1) { }
}
